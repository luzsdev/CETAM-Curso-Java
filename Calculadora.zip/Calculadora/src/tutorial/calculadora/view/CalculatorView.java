package tutorial.calculadora.view;

import calculadora.model.Calculator;

public class CalculatorView extends javax.swing.JFrame {
    
    Calculator calculadora = new Calculator();
    boolean segundoValor = false;
    String operacao;
    
    public CalculatorView() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LedCalcular = new javax.swing.JLabel();
        ButtonApagar = new javax.swing.JButton();
        ButtonPercent = new javax.swing.JButton();
        ButtonDividir = new javax.swing.JButton();
        ButtonMultiplicar = new javax.swing.JButton();
        ButtonSubtrair = new javax.swing.JButton();
        ButtonSomar = new javax.swing.JButton();
        ButtonIgualdade = new javax.swing.JButton();
        ButtonPonto = new javax.swing.JButton();
        Button0 = new javax.swing.JButton();
        Button1 = new javax.swing.JButton();
        Button2 = new javax.swing.JButton();
        Button3 = new javax.swing.JButton();
        Button4 = new javax.swing.JButton();
        Button5 = new javax.swing.JButton();
        Button6 = new javax.swing.JButton();
        Button7 = new javax.swing.JButton();
        Button8 = new javax.swing.JButton();
        Button9 = new javax.swing.JButton();
        ImgCalculator = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LedCalcular.setFont(new java.awt.Font("Square721 BT", 1, 24)); // NOI18N
        LedCalcular.setForeground(new java.awt.Color(255, 255, 255));
        LedCalcular.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LedCalcular.setToolTipText("");
        getContentPane().add(LedCalcular, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 210, 50));

        ButtonApagar.setBackground(new java.awt.Color(30, 30, 30));
        ButtonApagar.setContentAreaFilled(false);
        ButtonApagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonApagarActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonApagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 65, 47, 45));

        ButtonPercent.setBackground(new java.awt.Color(30, 30, 30));
        ButtonPercent.setToolTipText("");
        ButtonPercent.setContentAreaFilled(false);
        ButtonPercent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonPercentActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonPercent, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 60, 50));

        ButtonDividir.setBackground(new java.awt.Color(30, 30, 30));
        ButtonDividir.setContentAreaFilled(false);
        ButtonDividir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonDividirActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonDividir, new org.netbeans.lib.awtextra.AbsoluteConstraints(165, 60, 50, 50));

        ButtonMultiplicar.setBackground(new java.awt.Color(30, 30, 30));
        ButtonMultiplicar.setContentAreaFilled(false);
        ButtonMultiplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonMultiplicarActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonMultiplicar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, 50, 40));

        ButtonSubtrair.setBackground(new java.awt.Color(30, 30, 30));
        ButtonSubtrair.setContentAreaFilled(false);
        ButtonSubtrair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSubtrairActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonSubtrair, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 50, 50));

        ButtonSomar.setBackground(new java.awt.Color(30, 30, 30));
        ButtonSomar.setContentAreaFilled(false);
        ButtonSomar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSomarActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonSomar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 50, 50));

        ButtonIgualdade.setBackground(new java.awt.Color(30, 30, 30));
        ButtonIgualdade.setContentAreaFilled(false);
        ButtonIgualdade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonIgualdadeActionPerformed(evt);
            }
        });
        getContentPane().add(ButtonIgualdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 50, 50));

        ButtonPonto.setBackground(new java.awt.Color(30, 30, 30));
        ButtonPonto.setContentAreaFilled(false);
        getContentPane().add(ButtonPonto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 50, 50));

        Button0.setBackground(new java.awt.Color(30, 30, 30));
        Button0.setContentAreaFilled(false);
        Button0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button0ActionPerformed(evt);
            }
        });
        getContentPane().add(Button0, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 50, 50));

        Button1.setBackground(new java.awt.Color(30, 30, 30));
        Button1.setContentAreaFilled(false);
        Button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button1ActionPerformed(evt);
            }
        });
        getContentPane().add(Button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 50, 50));

        Button2.setBackground(new java.awt.Color(30, 30, 30));
        Button2.setContentAreaFilled(false);
        Button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button2ActionPerformed(evt);
            }
        });
        getContentPane().add(Button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 50, 50));

        Button3.setBackground(new java.awt.Color(30, 30, 30));
        Button3.setContentAreaFilled(false);
        Button3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button3ActionPerformed(evt);
            }
        });
        getContentPane().add(Button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 220, 50, 50));

        Button4.setBackground(new java.awt.Color(30, 30, 30));
        Button4.setContentAreaFilled(false);
        Button4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button4ActionPerformed(evt);
            }
        });
        getContentPane().add(Button4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 50, 50));

        Button5.setBackground(new java.awt.Color(30, 30, 30));
        Button5.setContentAreaFilled(false);
        Button5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button5ActionPerformed(evt);
            }
        });
        getContentPane().add(Button5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 50, 50));

        Button6.setBackground(new java.awt.Color(30, 30, 30));
        Button6.setContentAreaFilled(false);
        Button6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button6ActionPerformed(evt);
            }
        });
        getContentPane().add(Button6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 60, 50));

        Button7.setBackground(new java.awt.Color(30, 30, 30));
        Button7.setContentAreaFilled(false);
        Button7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button7ActionPerformed(evt);
            }
        });
        getContentPane().add(Button7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 50, 50));

        Button8.setBackground(new java.awt.Color(30, 30, 30));
        Button8.setContentAreaFilled(false);
        Button8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button8ActionPerformed(evt);
            }
        });
        getContentPane().add(Button8, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 50, 60));

        Button9.setBackground(new java.awt.Color(30, 30, 30));
        Button9.setContentAreaFilled(false);
        Button9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button9ActionPerformed(evt);
            }
        });
        getContentPane().add(Button9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 50, 40));

        ImgCalculator.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/calc.JPG"))); // NOI18N
        getContentPane().add(ImgCalculator, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonIgualdadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonIgualdadeActionPerformed
        if (segundoValor == true) {
            calculadora.setValor2(Double.parseDouble(LedCalcular.getText()));
            if(operacao == "soma") {
                calculadora.somar();
                LedCalcular.setText(String.valueOf(calculadora.getResultado()));
                operacao = "";
            }
            if(operacao == "subtracao") {
                calculadora.subtrair();
                LedCalcular.setText(String.valueOf(calculadora.getResultado()));
                operacao = "";
            }
            if(operacao == "divisao") {
                calculadora.dividir();
                LedCalcular.setText(String.valueOf(calculadora.getResultado()));
                operacao = "";
            }
            if(operacao == "multiplicacao") {
                calculadora.multiplicar();
                LedCalcular.setText(String.valueOf(calculadora.getResultado()));
                operacao = "";
            }
        }
    }//GEN-LAST:event_ButtonIgualdadeActionPerformed

    private void ButtonApagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonApagarActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText().substring(0, LedCalcular.getText().length() -1));
    }//GEN-LAST:event_ButtonApagarActionPerformed

    private void ButtonPercentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonPercentActionPerformed
        // TODO add your handling code here:
        calculadora.setValor1(Double.parseDouble(LedCalcular.getText()));
        calculadora.setResultado(calculadora.getValor1() / 100);
        LedCalcular.setText(String.valueOf(calculadora.getResultado()));
    }//GEN-LAST:event_ButtonPercentActionPerformed

    private void ButtonSomarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSomarActionPerformed
        // TODO add your handling code here:
        calculadora.setValor1(Double.parseDouble(LedCalcular.getText()));
        segundoValor = true;
        LedCalcular.setText("");
        operacao = "soma";
    }//GEN-LAST:event_ButtonSomarActionPerformed

    private void ButtonSubtrairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSubtrairActionPerformed
        // TODO add your handling code here:
        calculadora.setValor1(Double.parseDouble(LedCalcular.getText()));
        segundoValor = true;
        LedCalcular.setText("");
        operacao = "subtracao";
    }//GEN-LAST:event_ButtonSubtrairActionPerformed

    private void ButtonMultiplicarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonMultiplicarActionPerformed
        // TODO add your handling code here:
        calculadora.setValor1(Double.parseDouble(LedCalcular.getText()));
        segundoValor = true;
        LedCalcular.setText("");
        operacao = "multiplicacao";
    }//GEN-LAST:event_ButtonMultiplicarActionPerformed

    private void ButtonDividirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonDividirActionPerformed
        // TODO add your handling code here:
        calculadora.setValor1(Double.parseDouble(LedCalcular.getText()));
        segundoValor = true;
        LedCalcular.setText("");
        operacao = "divisao";                    
    }//GEN-LAST:event_ButtonDividirActionPerformed

    private void Button4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button4ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"4");
    }//GEN-LAST:event_Button4ActionPerformed

    private void Button0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button0ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"0");
    }//GEN-LAST:event_Button0ActionPerformed

    private void Button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button1ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"1");
    }//GEN-LAST:event_Button1ActionPerformed

    private void Button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button2ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"2");
    }//GEN-LAST:event_Button2ActionPerformed

    private void Button3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button3ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"3");
    }//GEN-LAST:event_Button3ActionPerformed

    private void Button5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button5ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"5");
    }//GEN-LAST:event_Button5ActionPerformed

    private void Button6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button6ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"6");
    }//GEN-LAST:event_Button6ActionPerformed

    private void Button7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button7ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"7");
    }//GEN-LAST:event_Button7ActionPerformed

    private void Button8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button8ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"8");
    }//GEN-LAST:event_Button8ActionPerformed

    private void Button9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button9ActionPerformed
        // TODO add your handling code here:
        LedCalcular.setText(LedCalcular.getText()+"9");
    }//GEN-LAST:event_Button9ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CalculatorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CalculatorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CalculatorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CalculatorView.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CalculatorView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Button0;
    private javax.swing.JButton Button1;
    private javax.swing.JButton Button2;
    private javax.swing.JButton Button3;
    private javax.swing.JButton Button4;
    private javax.swing.JButton Button5;
    private javax.swing.JButton Button6;
    private javax.swing.JButton Button7;
    private javax.swing.JButton Button8;
    private javax.swing.JButton Button9;
    private javax.swing.JButton ButtonApagar;
    private javax.swing.JButton ButtonDividir;
    private javax.swing.JButton ButtonIgualdade;
    private javax.swing.JButton ButtonMultiplicar;
    private javax.swing.JButton ButtonPercent;
    private javax.swing.JButton ButtonPonto;
    private javax.swing.JButton ButtonSomar;
    private javax.swing.JButton ButtonSubtrair;
    private javax.swing.JLabel ImgCalculator;
    private javax.swing.JLabel LedCalcular;
    // End of variables declaration//GEN-END:variables
}
